from rest_framework import generics, permissions, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth import get_user_model
from django.http import StreamingHttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
import json
import time
import threading
from .models import Feedback
from .serializers import UserSerializer, FeedbackSerializer, AcknowledgeFeedbackSerializer
from .permissions import IsManagerOrReadOnly, IsEmployeeOrManager
from .sse_manager import SSEManager

User = get_user_model()

# Initialize SSE Manager
sse_manager = SSEManager()

class CustomTokenObtainPairView(TokenObtainPairView):
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        if response.status_code == 200:
            # Add user info to response
            username = request.data.get('username')
            try:
                user = User.objects.get(username=username)
                response.data['user'] = UserSerializer(user).data
            except User.DoesNotExist:
                pass
        return response

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def user_profile(request):
    """Get current user profile"""
    serializer = UserSerializer(request.user)
    return Response(serializer.data)

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def team_list(request):
    """Get team members for managers"""
    if not request.user.is_manager:
        return Response(
            {'detail': 'Only managers can view team members.'}, 
            status=status.HTTP_403_FORBIDDEN
        )
    
    team_members = User.objects.filter(manager=request.user)
    serializer = UserSerializer(team_members, many=True)
    return Response(serializer.data)

class FeedbackListCreateView(generics.ListCreateAPIView):
    serializer_class = FeedbackSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if user.is_manager:
            # Managers see feedback they've given
            return Feedback.objects.filter(manager=user)
        else:
            # Employees see feedback they've received
            return Feedback.objects.filter(employee=user)
    
    def perform_create(self, serializer):
        feedback = serializer.save()
        
        # Send SSE notification to the employee
        employee_id = feedback.employee.id
        manager_id = feedback.manager.id
        
        # Serialize the feedback for SSE
        feedback_data = FeedbackSerializer(feedback).data
        
        # Send to employee
        sse_manager.send_to_user(
            user_id=employee_id,
            event_type='new_feedback',
            data=feedback_data
        )
        
        # Send to manager (for their dashboard update)
        sse_manager.send_to_user(
            user_id=manager_id,
            event_type='feedback_created',
            data=feedback_data
        )

class FeedbackDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = FeedbackSerializer
    permission_classes = [permissions.IsAuthenticated, IsManagerOrReadOnly]
    
    def get_queryset(self):
        user = self.request.user
        if user.is_manager:
            return Feedback.objects.filter(manager=user)
        else:
            return Feedback.objects.filter(employee=user)
    
    def perform_update(self, serializer):
        feedback = serializer.save()
        
        # Send SSE notification for feedback update
        employee_id = feedback.employee.id
        manager_id = feedback.manager.id
        
        feedback_data = FeedbackSerializer(feedback).data
        
        # Send to employee
        sse_manager.send_to_user(
            user_id=employee_id,
            event_type='feedback_updated',
            data=feedback_data
        )
        
        # Send to manager
        sse_manager.send_to_user(
            user_id=manager_id,
            event_type='feedback_updated',
            data=feedback_data
        )
    
    def perform_destroy(self, instance):
        employee_id = instance.employee.id
        manager_id = instance.manager.id
        feedback_id = instance.id
        
        instance.delete()
        
        # Send SSE notification for feedback deletion
        sse_manager.send_to_user(
            user_id=employee_id,
            event_type='feedback_deleted',
            data={'id': feedback_id}
        )
        
        sse_manager.send_to_user(
            user_id=manager_id,
            event_type='feedback_deleted',
            data={'id': feedback_id}
        )

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def acknowledge_feedback(request, pk):
    """Acknowledge feedback (employees only)"""
    try:
        feedback = Feedback.objects.get(pk=pk, employee=request.user)
    except Feedback.DoesNotExist:
        return Response(
            {'detail': 'Feedback not found.'}, 
            status=status.HTTP_404_NOT_FOUND
        )
    
    if feedback.acknowledged:
        return Response(
            {'detail': 'Feedback already acknowledged.'}, 
            status=status.HTTP_400_BAD_REQUEST
        )
    
    serializer = AcknowledgeFeedbackSerializer(feedback, data={'acknowledged': True})
    if serializer.is_valid():
        feedback = serializer.save()
        
        # Send SSE notification for acknowledgment
        employee_id = feedback.employee.id
        manager_id = feedback.manager.id
        
        feedback_data = FeedbackSerializer(feedback).data
        
        # Send to manager (they need to know it was acknowledged)
        sse_manager.send_to_user(
            user_id=manager_id,
            event_type='feedback_acknowledged',
            data=feedback_data
        )
        
        # Send to employee (for their dashboard update)
        sse_manager.send_to_user(
            user_id=employee_id,
            event_type='feedback_acknowledged',
            data=feedback_data
        )
        
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@method_decorator(csrf_exempt, name='dispatch')
class SSEView(View):
    """Server-Sent Events endpoint for real-time updates"""
    
    def get(self, request):
        # Get user from JWT token
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        if not auth_header.startswith('Bearer '):
            return StreamingHttpResponse(
                self._error_stream('Unauthorized'),
                content_type='text/plain',
                status=401
            )
        
        token = auth_header.split(' ')[1]
        
        try:
            from rest_framework_simplejwt.tokens import UntypedToken
            from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
            from django.contrib.auth import get_user_model
            
            UntypedToken(token)
            
            # Decode token to get user
            from rest_framework_simplejwt.authentication import JWTAuthentication
            jwt_auth = JWTAuthentication()
            validated_token = jwt_auth.get_validated_token(token)
            user = jwt_auth.get_user(validated_token)
            
        except (InvalidToken, TokenError, Exception):
            return StreamingHttpResponse(
                self._error_stream('Invalid token'),
                content_type='text/plain',
                status=401
            )
        
        # Create SSE stream for this user
        response = StreamingHttpResponse(
            self._event_stream(user.id),
            content_type='text/event-stream'
        )
        response['Cache-Control'] = 'no-cache'
        response['Connection'] = 'keep-alive'
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Headers'] = 'Cache-Control'
        
        return response
    
    def _event_stream(self, user_id):
        """Generate SSE stream for a specific user"""
        # Register this connection
        sse_manager.add_connection(user_id)
        
        try:
            # Send initial connection message
            yield f"data: {json.dumps({'type': 'connected', 'message': 'SSE connection established'})}\n\n"
            
            # Keep connection alive and send events
            while True:
                # Check for new events for this user
                events = sse_manager.get_events_for_user(user_id)
                
                for event in events:
                    yield f"event: {event['type']}\n"
                    yield f"data: {json.dumps(event['data'])}\n\n"
                
                # Send heartbeat every 30 seconds
                yield f"event: heartbeat\n"
                yield f"data: {json.dumps({'timestamp': time.time()})}\n\n"
                
                time.sleep(5)  # Check for new events every 5 seconds
                
        except GeneratorExit:
            # Client disconnected
            sse_manager.remove_connection(user_id)
        except Exception as e:
            # Handle any other errors
            sse_manager.remove_connection(user_id)
            yield f"event: error\n"
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
    
    def _error_stream(self, error_message):
        """Generate error stream"""
        yield f"event: error\n"
        yield f"data: {json.dumps({'error': error_message})}\n\n"
