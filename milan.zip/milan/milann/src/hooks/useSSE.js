"use client"

import { useEffect, useRef, useState } from "react"
import { useAuth } from "../contexts/AuthContext"

export const useSSE = (onEvent) => {
  const { user } = useAuth()
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState(null)
  const eventSourceRef = useRef(null)
  const reconnectTimeoutRef = useRef(null)
  const reconnectAttempts = useRef(0)
  const maxReconnectAttempts = 5

  const connect = () => {
    if (!user || eventSourceRef.current) return

    const token = localStorage.getItem("token")
    if (!token) return

    const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000/api"
    const url = `${apiBaseUrl}/sse/`

    try {
      // Create EventSource with authorization header
      const eventSource = new EventSource(url)

      // Add authorization header (Note: EventSource doesn't support custom headers directly)
      // We'll need to pass the token as a query parameter or handle it differently
      eventSourceRef.current = eventSource

      eventSource.onopen = () => {
        console.log("SSE: Connection opened")
        setIsConnected(true)
        setError(null)
        reconnectAttempts.current = 0
      }

      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          console.log("SSE: Received message:", data)

          if (onEvent) {
            onEvent(data)
          }
        } catch (err) {
          console.error("SSE: Error parsing message:", err)
        }
      }

      eventSource.addEventListener("new_feedback", (event) => {
        try {
          const data = JSON.parse(event.data)
          console.log("SSE: New feedback received:", data)
          if (onEvent) {
            onEvent({ type: "new_feedback", data })
          }
        } catch (err) {
          console.error("SSE: Error parsing new_feedback event:", err)
        }
      })

      eventSource.addEventListener("feedback_updated", (event) => {
        try {
          const data = JSON.parse(event.data)
          console.log("SSE: Feedback updated:", data)
          if (onEvent) {
            onEvent({ type: "feedback_updated", data })
          }
        } catch (err) {
          console.error("SSE: Error parsing feedback_updated event:", err)
        }
      })

      eventSource.addEventListener("feedback_deleted", (event) => {
        try {
          const data = JSON.parse(event.data)
          console.log("SSE: Feedback deleted:", data)
          if (onEvent) {
            onEvent({ type: "feedback_deleted", data })
          }
        } catch (err) {
          console.error("SSE: Error parsing feedback_deleted event:", err)
        }
      })

      eventSource.addEventListener("feedback_acknowledged", (event) => {
        try {
          const data = JSON.parse(event.data)
          console.log("SSE: Feedback acknowledged:", data)
          if (onEvent) {
            onEvent({ type: "feedback_acknowledged", data })
          }
        } catch (err) {
          console.error("SSE: Error parsing feedback_acknowledged event:", err)
        }
      })

      eventSource.addEventListener("feedback_created", (event) => {
        try {
          const data = JSON.parse(event.data)
          console.log("SSE: Feedback created:", data)
          if (onEvent) {
            onEvent({ type: "feedback_created", data })
          }
        } catch (err) {
          console.error("SSE: Error parsing feedback_created event:", err)
        }
      })

      eventSource.addEventListener("heartbeat", (event) => {
        // Handle heartbeat to keep connection alive
        console.log("SSE: Heartbeat received")
      })

      eventSource.addEventListener("error", (event) => {
        try {
          const data = JSON.parse(event.data)
          console.error("SSE: Server error:", data)
          setError(data.error)
        } catch (err) {
          console.error("SSE: Error event:", event)
        }
      })

      eventSource.onerror = (event) => {
        console.error("SSE: Connection error:", event)
        setIsConnected(false)

        if (eventSource.readyState === EventSource.CLOSED) {
          console.log("SSE: Connection closed")
          attemptReconnect()
        }
      }
    } catch (err) {
      console.error("SSE: Failed to create connection:", err)
      setError(err.message)
      attemptReconnect()
    }
  }

  const disconnect = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close()
      eventSourceRef.current = null
    }

    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current)
      reconnectTimeoutRef.current = null
    }

    setIsConnected(false)
    reconnectAttempts.current = 0
  }

  const attemptReconnect = () => {
    if (reconnectAttempts.current >= maxReconnectAttempts) {
      console.log("SSE: Max reconnection attempts reached")
      setError("Failed to reconnect after multiple attempts")
      return
    }

    const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000) // Exponential backoff, max 30s
    console.log(`SSE: Attempting to reconnect in ${delay}ms (attempt ${reconnectAttempts.current + 1})`)

    reconnectTimeoutRef.current = setTimeout(() => {
      reconnectAttempts.current++
      disconnect()
      connect()
    }, delay)
  }

  useEffect(() => {
    if (user) {
      connect()
    }

    return () => {
      disconnect()
    }
  }, [user])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect()
    }
  }, [])

  return {
    isConnected,
    error,
    reconnect: () => {
      disconnect()
      setTimeout(connect, 1000)
    },
  }
}
